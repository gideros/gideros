Make a copy of your gideros folder in program files  (possibly program files (x86) )
Copy the contents of the Gideros folder into that folder, overwrite any files
Make a shortcut to that gideros studio on your desktop
Run that Gideros Studio and player to have LuaJIT
If you export to Android or Windows then it will have LuaJIT libs
If you export to other platforms it won't work!