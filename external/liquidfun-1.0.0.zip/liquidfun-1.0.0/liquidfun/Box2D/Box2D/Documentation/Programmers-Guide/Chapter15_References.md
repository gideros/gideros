# References

Erin Catto's GDC Tutorials:<br/>
[http://code.google.com/p/box2d/downloads/list](http://code.google.com/p/box2d/downloads/list)<br/>
_Collision Detection in Interactive 3D Environments,_ Gino van den Bergen,
2004<br/>
_Real-Time Collision Detection,_ Christer Ericson, 2005
