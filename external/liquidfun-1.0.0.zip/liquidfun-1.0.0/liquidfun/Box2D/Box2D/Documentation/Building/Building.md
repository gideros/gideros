Building LiquidFun and Running Examples {#mainpage}
=======================================

LiquidFun is an extension of [Box2D](http://box2d.org), a 2D physics engine
for games.

API documentation is located in the Documentation/ folder and referenced
by our [landing page](../../index.html).

Instructions on how to build for:
- [Android](md__building_android.html)
- [Linux](md__building_linux.html)
- [Windows](md__building_windows.html)
- [OS X](md__building_o_s_x.html)
