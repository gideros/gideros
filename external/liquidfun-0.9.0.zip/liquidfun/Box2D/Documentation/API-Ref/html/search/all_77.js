var searchData=
[
  ['weight',['weight',['../structb2_particle_contact.html#a77703b9c45215f4058c3bc6493469053',1,'b2ParticleContact::weight()'],['../structb2_particle_body_contact.html#ac7610a92a2f9056d2d0a370d8bbb3222',1,'b2ParticleBodyContact::weight()']]]
];
