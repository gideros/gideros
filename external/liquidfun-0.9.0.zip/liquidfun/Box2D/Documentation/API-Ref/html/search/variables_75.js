var searchData=
[
  ['upperangle',['upperAngle',['../structb2_revolute_joint_def.html#a692cfe333ad12afd5753a6ec54e39a66',1,'b2RevoluteJointDef']]],
  ['upperbound',['upperBound',['../structb2_a_a_b_b.html#ad4a8ec483ba13a2c02918b01d058a18f',1,'b2AABB']]],
  ['uppertranslation',['upperTranslation',['../structb2_prismatic_joint_def.html#ae3eac123c7fe543071bdfcd1a6942350',1,'b2PrismaticJointDef']]],
  ['userdata',['userData',['../structb2_body_def.html#ae457dd1d39be09945eace6061121be29',1,'b2BodyDef::userData()'],['../structb2_fixture_def.html#a4f77ef2b2585a40899b61faf53db1093',1,'b2FixtureDef::userData()'],['../structb2_joint_def.html#a07eb150daaaa52fc09c3bcf402b295fe',1,'b2JointDef::userData()'],['../structb2_particle_def.html#af293c58640b3b403746d861b0b04e2f8',1,'b2ParticleDef::userData()'],['../structb2_particle_group_def.html#a6adc12d9288cc77ace1df5c04f9fa5cd',1,'b2ParticleGroupDef::userData()']]]
];
